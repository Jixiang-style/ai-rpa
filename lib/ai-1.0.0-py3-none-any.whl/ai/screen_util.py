# cython: language_level=3
import math
from math import dist

import numpy as np
import pyautogui
import pyscreeze
from PIL import Image, ImageFilter
from ai.config import AiConfig

from ai.image import image_binarize
from matplotlib import pyplot as plt, cm
from numpy import uint8
from pyscreeze import Point
from skimage.transform import probabilistic_hough_line

default_locate_kwargs = {
    'threshold': 0.86,
    'remove_bg_low': 20,
    'remove_bg_high': 180,
    'wand_threshold': 1
}


def locateMultipleOnScreen(locate_dict):
    for image, region in locate_dict.items():
        screen = pyautogui.screenshot()
        pos = pyautogui.locate(image, screen, region=region)
        if pos is not None:
            return True
    return False


def locateAllOnScreen(needle_image, region=None):
    result = list(pyautogui.locateAllOnScreen(needle_image, region=region))
    if len(result) > 0:
        return result
    return locateAll(needle_image, pyscreeze.screenshot(), region)


def locateOnScreen(needle_image, region=None, binarize_threshold=230, threshold=0.8):
    pos = pyautogui.locateOnScreen(needle_image, region=region)
    if pos is not None:
        return pos
    return fuzzy_locate(needle_image, pyscreeze.screenshot(), region,
                        binarize_threshold=binarize_threshold, threshold=threshold)


def locateCenterOnScreen(needle_image, region=None, binarize_threshold=230, threshold=0.8):
    return center(locateOnScreen(needle_image, region, binarize_threshold, threshold))


def center(pos):
    if pos is None:
        return None
    return Point(pos[0] + pos[2] // 2, pos[1] + pos[3] // 2)


def locateAll(needle_image, haystack_image, region=None):
    return fuzzy_locate(needle_image, haystack_image, region, all_flag=True)


def locate_one(needle_image, haystack_image, region=None, **kwargs):
    result = kmp_locate_one(needle_image, haystack_image, region=region)
    if result is None:
        result = fuzzy_locate_one(needle_image, haystack_image, region=region, **kwargs)
    return result


def kmp_locate_one(needle_image, haystack_image, region=None):
    return pyautogui.locate(needle_image, haystack_image, region=region)


def fuzzy_locate_one(needle_image, haystack_image, region=None, **kwargs):
    result = fuzzy_locate(needle_image, haystack_image, region=region, **kwargs)
    if len(result) == 1:
        return result[0]
    return None


def get_argument_by_key(kwargs, key):
    if key in kwargs:
        return kwargs[key]
    return default_locate_kwargs[key]


def fuzzy_locate(needle_image, haystack_image, region=None, all_flag=False, **kwargs):
    threshold = get_argument_by_key(kwargs, 'threshold')
    remove_bg_low = get_argument_by_key(kwargs, 'remove_bg_low')
    remove_bg_high = get_argument_by_key(kwargs, 'remove_bg_high')
    wand_threshold = get_argument_by_key(kwargs, 'wand_threshold')

    if isinstance(needle_image, str):
        needle_image = Image.open(needle_image).convert('L')
    if needle_image.mode != 'L':
        needle_image = needle_image.convert('L')
    if haystack_image.mode != 'L':
        haystack_image = haystack_image.convert('L')
    if region is not None:
        haystack_image = haystack_image.crop((region[0], region[1], region[0] + region[2], region[1] + region[3]))
    else:
        region = (0, 0)

    # print(list(remove_bg(needle_image)))

    # needle_image = Image.fromarray(remove_bg(needle_image, remove_bg_low, remove_bg_high, wand_threshold), mode='I').convert('L')
    # needle_image.show()
    # haystack_image = Image.fromarray(remove_bg(haystack_image, remove_bg_low, remove_bg_high, wand_threshold), mode='I').convert('L')
    # haystack_image.show()

    # needle_array = np.asarray(image_binarize(needle_image, 210))
    # haystack_array = np.asarray(image_binarize(haystack_image, 210))
    # remove_bg(haystack_image).show()
    # haystack_image.show()
    # image_binarize(needle_image, binarize_threshold).show()
    # image_binarize(haystack_image, binarize_threshold).show()
    needle_array = remove_bg(needle_image, remove_bg_low, remove_bg_high, wand_threshold)
    haystack_array = remove_bg(haystack_image, remove_bg_low, remove_bg_high, wand_threshold)
    result = image_match(needle_array, haystack_array, threshold, region, all_flag)
    return result


def image_match(needle_array, haystack_array, threshold, region, all_flag):
    needle_height, needle_width = needle_array.shape
    haystack_height, haystack_width = haystack_array.shape
    count, total_count = 0, needle_height * needle_width * threshold
    result = []
    for k in range(haystack_height - needle_height + 1):
        for j in range(haystack_width - needle_width + 1):
            b = haystack_array[k:k + needle_height, j: j + needle_width]
            tmp_count = np.sum(needle_array == b)
            if tmp_count > total_count:
                pos = [j + region[0], k + region[1], needle_width, needle_height]
                result.append(pos)
                if not all_flag:
                    return result
    return result


def remove_bg(image, low, high, wand_threshold):
    edge = image.filter(ImageFilter.FIND_EDGES)
    # edge.show()
    base_array = np.array(image, dtype=int)
    gray_array = np.array(image, dtype=int)
    edge_array = np.asarray(edge, dtype=int)
    conditions = [gray_array < low, gray_array > high]
    choices = [0, 255]
    gray_array = np.select(conditions, choices, gray_array)
    conditions = [edge_array < low, edge_array > high]
    choices = [0, 255]
    edge_array = np.select(conditions, choices, edge_array)
    conditions = [gray_array != edge_array]
    choices = [128]
    data = np.select(conditions, choices, base_array)
    data[:1] = 128
    data[data.shape[0] - 1:data.shape[0]] = 128
    data[:, :1] = 128
    data[:, data.shape[1] - 1:data.shape[1]] = 128
    return multiple_seed_wand(data, wand_threshold)


def multiple_seed_wand(data, wand_threshold):
    step = 5
    h, w = data.shape
    seed_y_list = [x for i, x in enumerate(range(h)) if i == h - 1 or x % step == 0]
    seed_x_list = [x for i, x in enumerate(range(w)) if i == w - 1 or x % step == 0]
    seed_list = []
    for i in seed_y_list:
        for j in seed_x_list:
            if data[i][j] == 128:
                seed_list.append((j, i))
    return WandFilter(wand_threshold).filter(data, seed_list)


class WandFilter:
    def __init__(self, threshold):
        self.threshold = threshold

    def filter(self, base_data, seed_list):
        height, width = base_data.shape
        seed_mark = np.zeros((height, width), dtype=int)
        x, y = seed_list[0]
        background = base_data[y, x]

        edge = set(seed_list)
        full_edge = set()
        while edge:
            new_edge = set()
            for (x, y) in edge:
                for (s, t) in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                    if (s, t) in full_edge or s < 0 or t < 0:
                        continue
                    try:
                        p = base_data[t, s]
                    except (ValueError, IndexError):
                        pass
                    else:
                        full_edge.add((s, t))
                        if abs(p - background) <= self.threshold:
                            seed_mark[t, s] = 255
                            new_edge.add((s, t))
            full_edge = edge
            edge = new_edge
        return seed_mark


def generate_rect(width, height, color):
    rect = Image.new('L', (width, height), color=color)
    return rect


line_cells = [
    np.asarray([[0, 0, 0], [255, 255, 255], [255, 255, 255], ]),
    np.asarray([[255, 255, 255], [255, 255, 255], [0, 0, 0], ]),
    np.asarray([[0, 255, 255], [0, 255, 255], [0, 255, 255], ]),
    np.asarray([[255, 255, 0], [255, 255, 0], [255, 255, 0], ]),
    np.asarray([[0, 0, 255], [0, 255, 255], [0, 255, 255], ]),
    np.asarray([[0, 0, 0], [0, 255, 255], [0, 255, 255], ]),
    np.asarray([[0, 255, 255], [0, 255, 255], [0, 0, 255], ]),
    np.asarray([[0, 255, 255], [0, 255, 255], [0, 0, 0], ]),
    np.asarray([[255, 255, 0], [255, 255, 0], [255, 0, 0], ]),
    np.asarray([[255, 0, 0], [255, 255, 0], [255, 255, 0], ]),
    np.asarray([[0, 0, 0], [255, 255, 0], [255, 255, 0], ]),
    np.asarray([[0, 255, 255], [0, 255, 255], [255, 255, 255], ]),
    np.asarray([[0, 0, 255], [255, 255, 255], [255, 255, 255], ]),
    np.asarray([[0, 0, 0], [0, 255, 255], [255, 255, 255], ]),
    np.asarray([[0, 255, 255], [255, 255, 255], [255, 255, 255], ]),
    np.asarray([[255, 255, 255], [255, 255, 255], [0, 255, 255], ]),
    np.asarray([[255, 255, 255], [0, 255, 255], [0, 255, 255], ]),
    np.asarray([[255, 255, 255], [255, 255, 255], [255, 0, 255], ]),
    np.asarray([[255, 255, 255], [255, 255, 255], [255, 0, 0], ]),
    np.asarray([[255, 255, 255], [255, 255, 255], [255, 255, 0], ]),
    np.asarray([[255, 255, 255], [255, 255, 0], [255, 255, 0], ]),
    np.asarray([[255, 255, 255], [0, 255, 0], [0, 0, 0], ]),
    np.asarray([[255, 255, 255], [0, 255, 255], [0, 0, 0], ]),
    np.asarray([[255, 255, 255], [255, 255, 255], [0, 0, 255], ]),
    np.asarray([[255, 255, 255], [255, 255, 255], [255, 255, 0], ]),
    np.asarray([[0, 0, 0], [255, 255, 0], [255, 255, 0], ]),
    np.asarray([[255, 0, 0], [255, 255, 0], [255, 255, 0], ]),
    np.asarray([[255, 0, 0], [255, 255, 0], [255, 255, 255], ]),
    np.asarray([[255, 0, 0], [255, 255, 255], [255, 255, 255], ]),
    np.asarray([[0, 0, 0], [255, 255, 0], [255, 255, 255], ]),
    np.asarray([[255, 255, 0], [255, 255, 0], [255, 255, 255], ]),
    np.asarray([[255, 255, 0], [255, 255, 255], [255, 255, 255], ])
]


def line_intersection(line1, line2):
    xdiff = (line1[0][0] - line1[1][0], line2[0][0] - line2[1][0])
    ydiff = (line1[0][1] - line1[1][1], line2[0][1] - line2[1][1])

    def det(a, b):
        return a[0] * b[1] - a[1] * b[0]

    div = det(xdiff, ydiff)
    if div == 0:
        return None

    d = (det(*line1), det(*line2))
    x = det(d, xdiff) / div
    y = det(d, ydiff) / div
    return [x, y]


def get_nearest_points(line1, line2):
    max_dis = float('inf')
    near, far = None, None
    for i in range(len(line1)):
        for j in range(len(line2)):
            dis = dist(line1[i], line2[j])
            if dis < max_dis:
                max_dis = dis
                near = (line1[i], line2[j])
                far = (line1[1 - i], line2[1 - j])
    result = None
    p_intersect = line_intersection(line1, line2)
    if p_intersect is not None and dist(p_intersect, near[0]) < 4 and dist(p_intersect, near[1]) < 4:
        result = (p_intersect, far[0], far[1])
    return result


angle_list = [math.pi / 3, math.pi / 2, math.pi * 3 / 5, math.pi * 2 / 3, math.pi * 5 / 7, math.pi * 3 / 4]


def get_polygon_angle(corner_points):
    a = [corner_points[0], corner_points[1]]
    b = [corner_points[0], corner_points[2]]
    ux, uy = a[1][0] - a[0][0], a[1][1] - a[0][1]
    vx, vy = b[1][0] - b[0][0], b[1][1] - b[0][1]
    theta_u = math.atan2(ux, uy)
    theta_v = math.atan2(vx, vy)
    theta_diff = theta_u - theta_v
    theta_diff_abs = abs(theta_diff)
    if theta_diff_abs >= math.pi:
        theta_diff_abs = 2 * math.pi - theta_diff_abs
    return theta_diff_abs


def check_angle(angle):
    for i, theta in enumerate(angle_list):
        if abs(angle - theta) < 0.1:
            return True
    return False


def corner_detect(line1, line2):
    l1 = [[line1[0][0], line1[0][1]], [line1[1][0], line1[1][1]]]
    l2 = [[line2[0][0], line2[0][1]], [line2[1][0], line2[1][1]]]
    corner_points = get_nearest_points(l1, l2)
    if corner_points is not None and check_angle(get_polygon_angle(corner_points)):
        return corner_points
    return None


def line_detect(data, filter_data):
    line_data = np.zeros(shape=data.shape, dtype=uint8)
    row, col = data.shape

    for i in range(1, row - 1):
        for j in range(1, col - 1):
            if filter_data[i][j] == 0:
                continue
            a = data[i - 1: i + 2, j - 1:j + 2]
            for b in line_cells:
                if np.array_equal(a, b):
                    line_data[i][j] = 255
                    break
    tested_angles = np.linspace(-np.pi / 2, np.pi / 2, 180, endpoint=False)
    lines = probabilistic_hough_line(line_data, threshold=15, line_length=12,
                                     line_gap=2, theta=tested_angles)

    line_list = []
    corner_list = []

    for i in range(len(lines)):
        for j in range(i + 1, len(lines)):
            corner_points = corner_detect(lines[i], lines[j])
            if corner_points is not None:
                corner_list.append(corner_points[0])
                line_list.append(lines[i])
                line_list.append(lines[j])
    result = -1
    for i in range(len(corner_list)):
        for j in range(i + 1, len(corner_list)):
            if abs(corner_list[i][1] - corner_list[j][1]) <= 1 and \
                    15 < abs(corner_list[i][0] - corner_list[j][0]) <= 50:
                result = (corner_list[i][0] + corner_list[j][0]) / 2
                break
    # show_plot(data, line_data, line_list)
    # print('corner_list', corner_list)
    # print('result', result)
    return result


def show_plot(data, line_data, line_list):
    fig, axes = plt.subplots(1, 3, figsize=(15, 5), sharex='all', sharey='all')
    ax = axes.ravel()
    ax[0].imshow(data, cmap=cm.gray)
    ax[0].set_title('Input image')
    ax[1].imshow(line_data, cmap=cm.gray)
    ax[1].set_title('Edges')
    ax[2].imshow(line_data * 0)
    for line in line_list:
        p0, p1 = line
        ax[2].plot((p0[0], p1[0]), (p0[1], p1[1]))
    ax[2].set_xlim((0, data.shape[1]))
    ax[2].set_ylim((data.shape[0], 0))
    ax[2].set_title('Probabilistic Hough')
    for a in ax:
        a.set_axis_off()
    plt.tight_layout()
    # plt.show()
    plt.savefig('test.png')


def get_qq_slide_distance(base_image):
    x_offset = 75
    y_offset = 5
    gray_image = base_image.crop((x_offset, y_offset, base_image.width, base_image.height)).convert('L')
    width, height = gray_image.width, gray_image.height
    binarized_image = image_binarize(gray_image, AiConfig.qq_crack_binary_threshold)
    inner_size = 18
    outer_size = 50
    rect_inner = generate_rect(inner_size, inner_size, 'white')
    rect_outer = generate_rect(outer_size, outer_size, 'white')
    pos_list = list(pyautogui.locateAll(rect_inner, binarized_image))
    outer_region_list = []

    for pos in pos_list:
        padding = (outer_size - inner_size) / 2
        left, top, outer_w, outer_h = int(pos.left - padding), int(pos.top - padding), int(outer_size), int(outer_size)
        if left < 0:
            left = 0
        if top < 0:
            top = 0
        if outer_w + left > width:
            outer_w = width - left
        if outer_h + top > height:
            outer_h = height - top
        outer_rect_region = (left, top, outer_w, outer_h)
        if outer_w < outer_size or outer_h < outer_size or left == 0 or top == 0:
            flag = None
        else:
            flag = pyautogui.locate(rect_outer, binarized_image, region=outer_rect_region)
        if flag is None:
            outer_region_list.append(outer_rect_region)

    data = np.array(binarized_image, dtype=uint8)
    data[data == 1] = 255
    filter_data = np.zeros(shape=data.shape, dtype=uint8)

    for outer_region in outer_region_list:
        row_start, row_end = outer_region[1], outer_region[1] + outer_region[3] + 1
        col_start, col_end = outer_region[0], outer_region[0] + outer_region[2] + 1
        filter_data[row_start:row_end, col_start:col_end] = data[row_start:row_end, col_start:col_end]

    target_x = line_detect(data, filter_data)
    start_x = 42
    drag_distance = -1
    if target_x != -1:
        drag_distance = x_offset + target_x - start_x
    return drag_distance
