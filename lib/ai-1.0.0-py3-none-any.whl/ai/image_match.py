#
# This program is commercial software; you can only redistribute it and/or modify
# it under the WARRANTY of Beijing Landing Technologies Co. Ltd.

# You should have received a copy license along with this program;
# If not, write to Beijing Landing Technologies, service@landingbj.com.
#

#
# image_match.py

# Copyright (C) 2020 Beijing Landing Technologies, China
#


import numpy as np
from PIL import Image, ImageOps
from ai.image import image_binarize, x_histogram, y_histogram, print_image
from pyscreeze import unicode
from ai.config import AiConfig

_DEBUG_ = AiConfig.debug_flag


def search(needleImage, haystackImage, region=None, threshold=1):
    if isinstance(needleImage, (str, unicode)):
        needleFileObj = open(needleImage, 'rb')
        needleImage = Image.open(needleFileObj)

    if isinstance(haystackImage, (str, unicode)):
        haystackFileObj = open(haystackImage, 'rb')
        haystackImage = Image.open(haystackFileObj)

    if region is not None:
        haystackImage = haystackImage.crop((region[0], region[1], region[0] + region[2], region[1] + region[3]))
    else:
        region = (0, 0)

    needleImage = ImageOps.grayscale(needleImage)
    haystackImage = ImageOps.grayscale(haystackImage)

    needleImage = needleImage.crop(needleImage.getbbox())
    haystackImage = haystackImage.crop(haystackImage.getbbox())

    haystackArray = np.asarray(haystackImage)
    needleArray = np.asarray(needleImage)
    haystack_height, haystack_width = haystackArray.shape
    needle_height, needle_width = needleArray.shape

    for i in range(haystack_height - needle_height):
        for j in range(haystack_width - needle_width):
            if match(needleArray, haystackArray, i, j, threshold):
                return True
    return False


def match(needleArray, haystackArray, start_y, start_x, threshold):
    needle_height, needle_width = needleArray.shape
    count, total_count = 0, needle_height * needle_width * (1 - threshold)
    for i in range(needle_height):
        y = start_y + i
        for j in range(needle_width):
            x = start_x + j
            if needleArray[i, j] != haystackArray[y, x]:
                count = count + 1
                if count > total_count:
                    return False
    return True


def histogram_divide(histogram, threshold):
    count_list = []
    for i in range(len(histogram)):
        if histogram[i] >= threshold:
            # count_list中放的是坐标
            count_list.append(i)

    result = []
    if len(count_list) == 0:
        return result
    a = b = count_list[0]

    for el in count_list[1:]:
        if el == b + 1:
            b = el
        else:
            if b - a >= 3:
                result.append(a)
                result.append(b)
            a = b = el
    # 3是最少连续数量
    if b - a >= 3:
        result.append(a)
        result.append(b)
    return result


def scale(image1, image2):
    width1, height1 = image1.size
    width2, height2 = image2.size
    width = width1
    if width1 > width2:
        width = width2
    height = height1
    if height1 > height2:
        height = height2
    image1 = image1.resize((width, height), Image.ANTIALIAS)
    image2 = image2.resize((width, height), Image.ANTIALIAS)
    return image1, image2


def icon_match(image, icon, region, binarize_threshold, match_ratio):
    binarized_icon = image_binarize(icon, binarize_threshold)
    width, height = binarized_icon.size
    if _DEBUG_:
        print_image(binarized_icon, 'binarized_icon_1.png')
    # }
    binarized_array = np.asarray(binarized_icon, dtype=int)
    x_count = x_histogram(binarized_array, 0, width, 0, height, 1)
    x_list = histogram_divide(x_count, 3)
    y_count = y_histogram(binarized_array, 0, width, 0, height, 1)
    y_list = histogram_divide(y_count, 3)
    x1, y1, x2, y2 = x_list[0], y_list[0], x_list[1], y_list[1]
    binarized_icon = binarized_icon.crop((x1, y1, x2, y2))
    if _DEBUG_:
        print_image(binarized_icon, 'binarized_icon_2.png')
    # }

    binarized_image = image_binarize(image, binarize_threshold).crop(region)
    if _DEBUG_:
        print_image(binarized_image, 'binarized_image_1.png')
    # }
    width, height = binarized_image.size
    image_array = np.asarray(binarized_image, dtype=int)
    x_count = x_histogram(image_array, 0, width, 0, height, 1)
    x_list = (histogram_divide(x_count, 3))
    y_count = y_histogram(image_array, 0, width, 0, height, 1)
    y_list = histogram_divide(y_count, 12)

    if len(x_list) < 2 or len(y_list) < 2:
        return False, 1

    for i in range(0, len(x_list), 2):
        for j in range(0, len(y_list), 2):
            region = (x_list[i], y_list[j], x_list[i + 1], y_list[j + 1])
            tmp_image = binarized_image.crop(region)
            if _DEBUG_:
                print_image(tmp_image, 'binarized_image_2' + '_' + str(i) + '_' + str(j) + '.png')
            # }
            image1, image2 = scale(tmp_image, binarized_icon)
            result = match(np.asarray(image2, dtype=int), np.asarray(image1, dtype=int), 0, 0, match_ratio)
            if result:
                scale_ratio = binarized_icon.size[0] / image1.size[0]
                return True, scale_ratio
    return False, 1

if __name__ == '__main__':
    print(search('../../image/target.png', '../../image/screenshot.png', region=(0, 0, 400, 500), threshold=0.9))
