#
# This program is commercial software; you can only redistribute it and/or modify
# it under the WARRANTY of Beijing Landing Technologies Co. Ltd.

# You should have received a copy license along with this program;
# If not, write to Beijing Landing Technologies, service@landingbj.com.
#

#
# config.py

# Copyright (C) 2020 Beijing Landing Technologies, China
#

# cython: language_level=3

class AiConfig:
    red_index = 0
    blue_index = 1
    green_index = 2
    orange_index = 3
    rgb_threshold = [{'red': 20, 'green': 150, 'blue': 150}, {'red': 50, 'green': 160, 'blue': 20},
                     {'red': 10, 'green': 80, 'blue': 100}, {'red': 20, 'green': 180, 'blue': 100}]
    wand_threshold = [(0, 0)] * 13

    cluster_k = 4
    ovality_threshold = 0.75

    left_thin_region = {}
    customer_logo = {}
    right_thin_region = {}
    my_logo = {}
    search_region_margin = 5

    cube_logo_size = 21
    find_edge_ratio = 0.8
    find_edge_offset = 30

    red_dot_bg_rgb = [(229, 230, 231), (217, 216, 216)]
    red_dot_bg_threshold = 10
    red_dot_bg_length = 60
    red_dot_bg_window = 30

    weibo_match_ratio = 0.8
    momo_match_ratio = 0.8
    match_ratio_51job = 0.8
    match_ratio_qq = 0.8
    match_ratio_ding6 = 0.8
    match_ratio_whatsapp = 0.8
    match_ratio_line = 0.8

    weibo_binarize_threshold = 206
    momo_binarize_threshold = 210
    job51_binarize_threshold = 220
    qq_binarize_threshold = 206
    ding6_binarize_threshold = 206
    whatsapp_binarize_threshold = 206
    line_binarize_threshold = 206

    whatsapp_seed_x_start = 30
    line_seed_x_start = 55
    line_seed_x_length = 60

    contour_threshold = 200
    _cross_filter_threshold = 220
    _cross_filter_min_size = 3
    _cross_filter_size = 5
    _cross_filter_extend_size = 9

    cross_filter_params = (
        _cross_filter_threshold,
        _cross_filter_min_size,
        _cross_filter_size,
        _cross_filter_extend_size
    )

    wand_x_threshold = 25
    wand_y_threshold = 30
    seed_search_color = (220, 220, 85)
    seed_search_start_x = 32
    seed_search_thresh = 110
    wand_connect_num = 4
    wand_candidate_type = 'RGB'
    qq_crack_binary_threshold = 200

    @classmethod
    def set_code_crack_params(cls, params):
        cls.wand_x_threshold = params['wand_x_threshold']
        cls.wand_y_threshold = params['wand_y_threshold']
        cls.seed_search_color = params['seed_search_color']
        cls.seed_search_start_x = params['seed_search_start_x']
        cls.seed_search_thresh = params['seed_search_thresh']
        cls.wand_connect_num = params['wand_connect_num']
        cls.wand_candidate_type = params['wand_candidate_type']

    debug_flag = False
    debug_directory = 'D:/Test/rpa'
