#
# This program is commercial software; you can only redistribute it and/or modify
# it under the WARRANTY of Beijing Landing Technologies Co. Ltd.

# You should have received a copy license along with this program;
# If not, write to Beijing Landing Technologies, service@landingbj.com.
#

#
# image.py

# Copyright (C) 2020 Beijing Landing Technologies, China
#

# cython: language_level=3
import math
import sys

import pyautogui
from PIL import Image, ImageFilter
import numpy as np

import pyscreeze
from ai.config import AiConfig
from ai.kmeans import fast_cluster_centers

_DEBUG_ = AiConfig.debug_flag

logo_image = None


def generate_logo(cube_size):
    global logo_image
    logo_image = Image.new('L', (cube_size, cube_size), color='black')


def wand_edge(base_image, app_type_index):
    base_data = np.array(base_image, dtype=int)
    edge_image = base_image.filter(ImageFilter.FIND_EDGES)
    edge_data = np.asarray(edge_image, dtype=int)

    wand_x_threshold, wand_y_threshold = AiConfig.wand_threshold[app_type_index]
    wand = WandFilter(wand_x_threshold)
    centroid_x, centroid_y = get_wand_seed(edge_data)
    wand_data = wand.filter(base_data, centroid_x, centroid_y)

    wand_edge_image = Image.fromarray(np.uint8(wand_data), 'L')
    return wand_edge_image


def get_wand_seed(edge_data):
    height, width = edge_data.shape
    centroid_x, centroid_y = width // 2, height // 2
    start = int(width * 0.1)
    n_array = edge_data[centroid_y, start:width - 20]

    count = 0
    # 任何一行有边缘检测标记点，则放弃，寻早新的候选行
    while np.any(n_array[:] != 0) and count < 1024:
        centroid_y = centroid_y + 1
        if centroid_y >= height:
            centroid_y = centroid_y - height
        n_array = edge_data[centroid_y, start:width - 20]
        count = count + 1

    return centroid_x, centroid_y


mark_seed_grown = 255
mark_seed_marked = 0
mark_seed_dropped = 64
mark_seed_candidate = 128


class WandFilter:
    def __init__(self, threshold):
        self.threshold = threshold

    # 从某个种子开始生长，差距比较小的赋255白色标记出来
    def filter(self, base_data, seed_x, seed_y):
        seed_mark = region_grow_seed(self, base_data, seed_x, seed_y)
        height, width = seed_mark.shape

        for y in range(height):
            for x in range(width):
                if seed_mark[y, x] != mark_seed_candidate:
                    continue

                seeds = [Point(x, y)]
                region, ovality, min_x, min_y, max_x, max_y = region_grow_seeds(seed_mark, seeds, 1)

                rw = max_x - min_x
                rh = max_y - min_y
                if ovality >= AiConfig.ovality_threshold \
                        and AiConfig.cube_logo_size ** 2 < len(region) < 8 * AiConfig.cube_logo_size**2 \
                        and AiConfig.cube_logo_size < rw < 3 * AiConfig.cube_logo_size \
                        and AiConfig.cube_logo_size < rh < 3 * AiConfig.cube_logo_size:
                    mark = mark_seed_marked
                else:
                    mark = mark_seed_dropped

                for (s, t) in region:
                    seed_mark[t, s] = mark
        return seed_mark


class Point(object):
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __str__(self):
        return "x=" + str(self.x) + ", " + "y=" + str(self.y)

    def __repr__(self):
        return "x=" + str(self.x) + ", " + "y=" + str(self.y)


# 8路或者4路邻居
def select_connects(p):
    if p != 0:
        connects = [Point(-1, -1), Point(0, -1), Point(1, -1), Point(1, 0),     # 左上、上、右上、右
                    Point(1, 1),   Point(0, 1), Point(-1, 1), Point(-1, 0)]     # 右下、下、左下、左
    else:
        connects = [Point(0, -1), Point(1, 0), Point(0, 1), Point(-1, 0)]       # 上、右、下、左
    return connects


# 从某个种子开始生长，差距比较小的赋255白色标记出来
def region_grow_seed(self, base_data, seed_x, seed_y):
    height, width = base_data.shape
    # 初始化默认为128值
    seed_mark = np.zeros((height, width))
    seed_mark.fill(mark_seed_candidate)

    x, y = seed_x, seed_y
    background = base_data[y, x]
    # 以集合的方式操作
    edge = {(x, y)}
    full_edge = set()
    while edge:
        new_edge = set()
        for (x, y) in edge:
            for (s, t) in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                if (s, t) in full_edge or s < 0 or t < 0:
                    continue
                try:
                    p = base_data[t, s]
                except (ValueError, IndexError):
                    pass
                else:
                    full_edge.add((s, t))
                    if abs(p - background) <= self.threshold:
                        seed_mark[t, s] = mark_seed_grown
                        new_edge.add((s, t))
        full_edge = edge
        edge = new_edge     # 新的候选种子
    return seed_mark


# 多种子节点的区域生长
def region_grow_seeds(base_data, seeds, thresh, p=1):
    height, width = base_data.shape
    seed_mark = np.zeros((height, width))       # 初始化为0
    seed_list = []
    for seed in seeds:
        seed_list.append(seed)
    label = mark_seed_grown
    connects = select_connects(p)

    min_x = math.inf
    max_x = 0
    min_y = math.inf
    max_y = 0
    area = 0
    region_set = set()

    while len(seed_list) > 0:
        # 以堆栈的方式操作
        current_point = seed_list.pop(0)

        seed_mark[current_point.y, current_point.x] = label
        for i in range(8):
            tmp_x = current_point.x + connects[i].x
            tmp_y = current_point.y + connects[i].y
            if tmp_x < 0 or tmp_y < 0 or tmp_x >= width or tmp_y >= height:
                continue

            # 获取指定像素的灰度差
            diff = abs(base_data[current_point.y, current_point.x] - base_data[tmp_y, tmp_x])
            if diff < thresh and seed_mark[tmp_y, tmp_x] == 0:
                seed_mark[tmp_y, tmp_x] = label
                seed_list.append(Point(tmp_x, tmp_y))
                region_set.add((tmp_x, tmp_y))
                area = area + 1

                if tmp_y < min_y:
                    min_y = tmp_y
                if tmp_y > max_y:
                    max_y = tmp_y
                if tmp_x < min_x:
                    min_x = tmp_x
                if tmp_x > max_x:
                    max_x = tmp_x

    d = max(max_x - min_x + 1, max_y - min_y + 1)
    area = np.count_nonzero(seed_mark == label)
    ovality = area / (d * d)
    # 区域像素点、椭圆度、左侧边界、上侧边界、右侧边界、下侧边界
    return region_set, ovality, min_x, min_y, max_x, max_y


def crop(screenshot, crop_region):
    left = crop_region[0]
    top = crop_region[1]
    right = crop_region[0] + crop_region[2]
    bottom = crop_region[1] + crop_region[3]
    image = screenshot.crop((left, top, right, bottom))
    return image


# 查找头像
def find_logo(screenshot, crop_region, app_type_index, app_index):
    wand_edge_image = wand_edge(crop(screenshot, crop_region), app_type_index)
    # 调试信息 {
    if _DEBUG_:
        print_image(screenshot, 'screenshot_find_log.png')
        print_image(wand_edge_image, 'wand_edge_find_log.png')
        print_image(logo_image, 'logo_image.png')
    # }
    wand_edge_data = np.asarray(wand_edge_image, dtype=int)

    pos_list = list(pyscreeze.locateAll(logo_image, wand_edge_image, grayscale=True))

    if len(pos_list) == 0:
        return -1, -1, False

    visited = set()
    pos_result = []
    middle_x = crop_region[2] / 2

    for pos in reversed(pos_list):
        center_pos = pyautogui.center(pos)
        if (center_pos.x, center_pos.y) in visited or wand_edge_data[center_pos.y, center_pos.x] != mark_seed_marked:
            continue

        seeds = [Point(center_pos.x, center_pos.y)]                             # 以匹配到的区域中心为生长点
        region, ovality = region_grow_seeds(wand_edge_data, seeds, 10)[0:2]     # 取前二个返回值
        visited.update(region)

        if ovality >= AiConfig.ovality_threshold:
            pos_result.append(Point(center_pos.x, center_pos.y))

    if len(pos_result) == 0:
        return -1, -1, False

    your = Point(middle_x + 1, 0)    # 左侧头像
    mine = Point(middle_x - 1, 0)    # 右侧头像
    for pos in reversed(pos_result):
        # 调试信息 {
        if _DEBUG_:
            print(pos)
        # }
        if pos.x <= your.x and pos.y >= your.y:
            your = pos

        if pos.x >= mine.x and pos.y >= mine.y:
            mine = pos

    if mine.y > your.y or your.x > middle_x:
        return -1, -1, False
    else:
        AiConfig.customer_logo[app_index], AiConfig.left_thin_region[app_index] = save_logo(screenshot, your,
                                                                                            crop_region)
    if mine.x > middle_x:
        AiConfig.my_logo[app_index], AiConfig.right_thin_region[app_index] = save_logo(screenshot, mine, crop_region)

    return your.x + crop_region[0], your.y + crop_region[1], mine.x > middle_x


def save_logo(screenshot, logo_pos, crop_region):
    logo_center = (logo_pos.x + crop_region[0], logo_pos.y + crop_region[1])
    offset = int(AiConfig.cube_logo_size / 2)
    left, top = logo_center[0] - offset, logo_center[1] - offset
    right, bottom = logo_center[0] + offset, logo_center[1] + offset
    logo = screenshot.crop((left, top, right, bottom))
    thin_region_width = AiConfig.cube_logo_size + AiConfig.search_region_margin * 2
    thin_region_height = crop_region[3]
    thin_region = (left - AiConfig.search_region_margin, crop_region[1], thin_region_width, thin_region_height)
    return logo, thin_region


def fast_logo(screenshot, crop_region, app_index):
    pos_result = list(
        pyautogui.locateAll(AiConfig.customer_logo[app_index], screenshot, region=AiConfig.left_thin_region[app_index]))
    pos_result += list(
        pyautogui.locateAll(AiConfig.my_logo[app_index], screenshot, region=AiConfig.right_thin_region[app_index]))

    if len(pos_result) == 0:
        return 0, 0
    first = pyautogui.center(pos_result[0])
    your = Point(first.x, first.y)
    mine = Point(first.x, first.y)
    for pos in pos_result:
        pos = pyautogui.center(pos)
        if pos.x <= your.x and pos.y >= your.y:
            your = Point(pos.x, pos.y)
        if pos.x >= mine.x and pos.y >= mine.y:
            mine = Point(pos.x, pos.y)
    if mine.y > your.y or your.x - crop_region[0] > crop_region[2] / 2:
        return -1, -1
    # print("--- fast logo %s seconds ---" % (time.time() - start_time))
    return your.x, your.y


def find_edge(edge_data, region):
    xl, yl, width, height = region
    xr, yr = xl + width, yl + height
    new_xl = x_histogram_index(edge_data, xl, yl, yr)
    new_xr = x_histogram_index(edge_data, xr, yl, yr)
    new_yl = y_histogram_index(edge_data, yl, xl, xr)
    new_yr = y_histogram_index(edge_data, yr, xl, xr)
    return new_xl, new_yl, new_xr, new_yr


def x_histogram_index(image_array, x, y1, y2):
    x1, x2 = x - AiConfig.find_edge_offset, x + AiConfig.find_edge_offset
    threshold = (y2 - y1) * AiConfig.find_edge_ratio
    count_list = x_histogram(image_array, x1, x2, y1, y2, 11)
    result = get_nearest_index(count_list, x, threshold)
    return result


def y_histogram_index(image_array, y, x1, x2):
    y1, y2 = y - AiConfig.find_edge_offset, y + AiConfig.find_edge_offset
    threshold = (x2 - x1) * AiConfig.find_edge_ratio
    count_list = y_histogram(image_array, x1, x2, y1, y2, 11)
    result = get_nearest_index(count_list, y, threshold)
    return result


def x_histogram(image_array, x1, x2, y1, y2, threshold):
    width = image_array.shape[1]
    count_list = [0] * width
    if x1 < 0:
        x1 = 0
    if x2 >= width:
        x2 = width - 1
    for i in range(x1, x2):
        for j in range(y1, y2):
            p = image_array[j, i]
            if p >= threshold:
                count_list[i] = count_list[i] + 1
    return count_list


def y_histogram(image_array, x1, x2, y1, y2, threshold):
    height = image_array.shape[0]
    count_list = [0] * height
    if y1 < 0:
        y1 = 0
    if y2 >= height:
        y2 = height - 1
    for j in range(y1, y2):
        for i in range(x1, x2):
            p = image_array[j, i]
            if p >= threshold:
                count_list[j] = count_list[j] + 1
    return count_list


def get_nearest_index(count_list, index, threshold):
    y_index = []
    for num, count in enumerate(count_list, start=0):
        if count > threshold:
            y_index.append(num)
    result = index
    dist = sys.maxsize
    for i in y_index:
        tmp = abs(i - index)
        if tmp < dist:
            result = i
            dist = tmp
    return result


# 将图像二值化
def image_binarize(image, thresh):
    fn = lambda x: mark_seed_grown if x < thresh else mark_seed_marked
    result = image.convert('L').point(fn, mode='1')
    return result


def get_search_position(line, threshold):
    gradient = []
    for i in range(1, len(line)):
        diff = line[i] - line[i - 1]
        if abs(diff) > 3:
            gradient.append((diff, i))
    for j in range(1, len(gradient)):
        diff1, idx1 = gradient[j]
        diff2, idx2 = gradient[j - 1]
        if abs(diff1 + diff2) <= 3 and abs(idx1 - idx2 - threshold) <= 10:
            return (idx1 + idx2) // 2
    return -1


low, high = 50, 250


def remove_bg(image):
    edge = image.filter(ImageFilter.FIND_EDGES)
    base_array = np.array(image, dtype=int)
    gray_array = np.array(image, dtype=int)
    edge_array = np.asarray(edge)
    conditions = [gray_array < low, gray_array > high]
    choices = [0, 255]
    gray_array = np.select(conditions, choices, gray_array)
    conditions = [edge_array > high]
    choices = [1]
    a = np.select(conditions, choices, 0)
    b = np.full(a.shape, 0)
    y_offset, x_offset = a.shape[0] - 4, a.shape[1] - 4
    matrix_list = []
    for i in range(0, 5):
        for j in range(0, 5):
            matrix_list.append(a[j:j + y_offset, i:i + x_offset])
    b[2:-2, 2:-2] = np.asarray(matrix_list).sum(axis=0)

    conditions = [gray_array != edge_array, (base_array < low) & (b < 8)]
    choices = [128, 128]
    result = np.select(conditions, choices, base_array)
    result[:10] = 128
    result[a.shape[0] - 10:a.shape[0]] = 128
    result[:, :10] = 128
    result[:, a.shape[1] - 10:a.shape[1]] = 128

    return result


def get_seed_point(image_no_bg, direction, app_type):
    count_array = ((image_no_bg < low) | (image_no_bg > high))
    columns = count_array.sum(0)
    rows = count_array.sum(1)

    if direction == 0:
        if app_type == 11:
            x_start, x_end = AiConfig.whatsapp_seed_x_start, int(len(columns) / 2)
        else:
            x_start, x_end = AiConfig.line_seed_x_start, AiConfig.line_seed_x_start + AiConfig.line_seed_x_length
    else:
        if app_type == 11:
            x_start, x_end = int(len(columns) / 2), len(columns)
        else:
            x_start, x_end = len(columns) - AiConfig.line_seed_x_length, len(columns)

    for i in reversed(range(len(rows))):
        if rows[i] < 5:
            continue
        for j in range(len(columns)):
            if columns[j] < 5:
                continue
            y = i
            a = image_no_bg[y, x_start:x_end]
            x_array = np.where(np.logical_or(a < low, a > high))
            if len(x_array[0]) == 0:
                continue
            x = x_array[0][0].item() + x_start
            return x, y
    return 0, 0


def move_seed(centroid_x, centroid_y, base_data):
    n_array = base_data[centroid_y, centroid_x:centroid_x + 20]
    count = 0
    while not np.all(n_array == n_array[0]) and count < 10:
        centroid_y = centroid_y - 3
        if centroid_y < 0:
            break
        n_array = base_data[centroid_y, centroid_x:centroid_x + 20]
        count = count + 1
    return centroid_x, centroid_y


# 没有头像的前提下，获取消息
def find_message_no_logo(screenshot, crop_region, app_type):
    image = crop(screenshot, crop_region)
    base_data = np.asarray(image, dtype=int)
    image_no_bg = remove_bg(image)

    left_centroid_x, left_centroid_y   = get_seed_point(image_no_bg, 0, app_type)
    right_centroid_x, right_centroid_y = get_seed_point(image_no_bg, 1, app_type)

    if right_centroid_y > left_centroid_y:
        seed_x, seed_y = move_seed(right_centroid_x, right_centroid_y, base_data)
    else:
        seed_x, seed_y = move_seed(left_centroid_x, left_centroid_y, base_data)

    return find_message_by_margin(seed_x, seed_y, crop_region, base_data)


def find_message_by_margin(seed_x, seed_y, crop_region, base_data):
    seeds = [Point(seed_x, seed_y)]
    region, ovality, min_x, min_y, max_x, max_y = region_grow_seeds(base_data, seeds, 1)

    left_margin, right_margin = min_x, crop_region[2] - max_x
    if right_margin > left_margin:
        return min_x + crop_region[0], max_y + crop_region[1], True
    return -1, -1, False


# 调试打印图像到文件
def print_image(image, fp):
    image.save(AiConfig.debug_directory + '/' + fp, "PNG")
