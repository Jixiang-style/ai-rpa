#
# This program is commercial software; you can only redistribute it and/or modify
# it under the WARRANTY of Beijing Landing Technologies Co. Ltd.

# You should have received a copy license along with this program;
# If not, write to Beijing Landing Technologies, service@landingbj.com.
#

#
# kmeans.py

# Copyright (C) 2020 Beijing Landing Technologies, China
#

# cython: language_level=3
import math
import random
import numpy as np


class Canopy:
    def __init__(self, dataset):
        self.dataset = dataset
        self.t1 = 0
        self.t2 = 0

    def set_threshold(self, t1, t2):
        if t1 > t2:
            self.t1 = t1
            self.t2 = t2
        else:
            print('t1 needs to be larger than t2!')

    def euclidean_distance(self, vec1, vec2):
        return math.sqrt(((vec1 - vec2) ** 2).sum())

    def get_rand_index(self):
        return random.randint(0, len(self.dataset) - 1)

    def clustering(self):
        if self.t1 == 0:
            print('Please set the threshold.')
        else:
            canopies = []  # 用于存放最终归类结果
            while len(self.dataset) != 0:
                rand_index = self.get_rand_index()
                current_center = self.dataset[rand_index]  # 随机获取一个中心点，定为P点
                current_center_list = []  # 初始化P点的canopy类容器
                delete_list = []  # 初始化P点的删除容器
                self.dataset = np.delete(
                    self.dataset, rand_index, 0)  # 删除随机选择的中心点P
                for datum_j in range(len(self.dataset)):
                    datum = self.dataset[datum_j]
                    distance = self.euclidean_distance(current_center, datum)  # 计算选取的中心点P到每个点之间的距离
                    if distance < self.t1:
                        current_center_list.append(datum)
                    if distance < self.t2:
                        delete_list.append(datum_j)  # 若小于t2则归入删除容器
                self.dataset = np.delete(self.dataset, delete_list, 0)
                canopies.append((current_center, current_center_list))
        return canopies


def dist(a, b, ax=1):
    return np.linalg.norm(a - b, axis=ax)


def init_center(k, x):
    temp = [x[np.random.randint(0, len(x))]]
    while len(temp) < k:
        d2 = np.array([min([np.square(dist(i, c, None)) for c in temp]) for i in x])
        prob = d2 / d2.sum()
        cum_prob = prob.cumsum()
        r = np.random.random()
        ind = np.where(cum_prob >= r)[0][0]
        temp.append(x[ind])
    return np.array(temp)


def cluster_centers(x, k):
    center = init_center(k, x)
    clusters = np.zeros(len(x))
    center_old = np.zeros(center.shape)
    err = dist(center, center_old, None)
    while err > 0.1:
        for i in range(len(x)):
            distances = dist(x[i], center)
            print(distances)
            clusters[i] = np.argmin(distances)
            print(clusters[i])
        center_old = np.copy(center)
        for i in range(k):
            points = [x[j] for j in range(len(x)) if clusters[j] == i]
            if points:
                center[i] = np.mean(points, axis=0)
        err = dist(center, center_old, None)
    return center


def fast_cluster_centers(x, k):
    center = init_center(k, x)
    center_old = np.zeros(center.shape)
    err = dist(center, center_old, None)
    while err != 0:
        assigned_centroids = np.argmin(dist(x[:, None, :], center[None, :, :]), axis=1)
        for c in range(center.shape[1]):
            cluster_members = x[assigned_centroids == c]
            if len(cluster_members) == 0:
                continue
            cluster_members = cluster_members.mean(axis=0)
            center[c] = cluster_members

        center_old = np.copy(center)
        err = dist(center, center_old, None)
    return center


if __name__ == '__main__':
    dataset = np.random.rand(500, 2)
    t1 = 0.6
    t2 = 0.4
    gc = Canopy(dataset)
    gc.set_threshold(t1, t2)
    canopies = gc.clustering()
    print('Get %s initial centers.' % len(canopies))
    # print(canopies)
