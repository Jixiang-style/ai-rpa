#
# This program is commercial software; you can only redistribute it and/or modify
# it under the WARRANTY of Beijing Landing Technologies Co. Ltd.

# You should have received a copy license along with this program;
# If not, write to Beijing Landing Technologies, service@landingbj.com.
#

#
# new_message.py

# Copyright (C) 2020 Beijing Landing Technologies, China
#

# cython: language_level=3
import time
import numpy as np
from PIL import Image, ImageDraw

from ai.config import AiConfig
from ai.image import crop


# 产生一个纯红色的球，直径为round_size
def generate_red_dot(round_size):
    im = Image.new('RGB', (round_size, round_size), color=(255, 255, 255))
    draw = ImageDraw.Draw(im)
    draw.ellipse((0, 0, round_size - 1, round_size - 1), fill=(255, 0, 0))
    red_dot_array = np.asarray(im)
    red_index = []
    rows, cols = red_dot_array.shape[0], red_dot_array.shape[1]

    red_count = 0
    for y in range(rows):
        start, end = 0, 0
        for x in range(cols):
            if start == 0 and red_dot_array[y, x, 1] == 0:  # 比较绿色同通道或者比较蓝色通道都可以
                start = x
            if red_dot_array[y, x, 1] == 0:
                end = x
                red_count = red_count + 1
        red_index.append([start, end])
    # 返回 红点矩阵、每行的红点起始位置，红点像素总数
    return red_dot_array, red_index, red_count


def find_new_message(screenshot, contact_region, red_dot_array, red_index, red_count, color_index):
    image = crop(screenshot, contact_region)
    image_array = np.asarray(image, dtype='int64')
    rows, cols = image_array.shape[0], image_array.shape[1]
    red_count_list = [0] * rows

    visited = []
    radius = len(red_index) // 2
    for y in range(0, rows, radius):
        for x in range(0, cols, radius):
            if not rgb_delta(image_array, y, x, color_index):
                red_count_list[y] = red_count_list[y] + 1
                visited.extend(image_array[y-radius:y])
                visited.extend(image_array[y+1:y+radius+1])
                break

    candidates = np.unique(visited)
    for y in candidates:
        for x in range(cols):
            if not rgb_delta(image_array, y, x, color_index):
                red_count_list[y] = red_count_list[y] + 1
                break

    red_dots = []
    y = 0
    while y < rows:
        if red_count_list[y] == 0:
            y = y + 1
            continue
        if y + red_dot_array.shape[0] <= rows:
            red_dot_xy = find_new_dot(image_array, y, red_dot_array, red_index, red_count, color_index)
            if red_dot_xy is not None and red_dot_xy[0] > 50:
                red_dot_xy = red_dot_xy[0] + contact_region[0], red_dot_xy[1] + contact_region[1]
                red_dots.append(red_dot_xy)
                y = y + red_dot_array.shape[0]
            else:
                y = y + 1
        else:
            break
    return red_dots


def find_new_dot(image_array, first_row, dot_array, dot_index, dot_count, color_index):
    rows, cols = image_array.shape[0], image_array.shape[1]
    rgb_threshold = AiConfig.rgb_threshold[color_index]
    result = None
    for k in range(cols, -1, -1):
        if k - dot_array.shape[1] < 0:
            break
        red, green, blue = 0, 0, 0
        for i in range(first_row, first_row + dot_array.shape[0]):
            r = i - first_row
            x, y = dot_index[r][0], dot_index[r][1]
            for j in range(x, y + 1):
                delta_red = image_array[i, k - j, 0] - dot_array[r, j, 0]
                delta_green = image_array[i, k - j, 1] - dot_array[r, j, 1]
                delta_blue = image_array[i, k - j, 2] - dot_array[r, j, 2]

                red = red + delta_red
                green = green + delta_green
                blue = blue + delta_blue

                if color_index == AiConfig.red_index or color_index == AiConfig.orange_index:
                    red = red - 2 * delta_red
                elif color_index == AiConfig.blue_index:
                    blue = blue - 2 * delta_blue
                elif color_index == AiConfig.green_index:
                    green = green - 2 * delta_green

        red, green, blue = red / dot_count, green / dot_count, blue / dot_count

        if red <= rgb_threshold['red'] and green < rgb_threshold['green'] and blue < rgb_threshold['blue']:
            result = (k, first_row)
            break

    return result


def red_dot_vertical_valid(image_data, x, y):
    for i in range(y, y + AiConfig.red_dot_bg_length - AiConfig.red_dot_bg_window):
        for bg_rgb in AiConfig.red_dot_bg_rgb:
            count = 0
            for j in range(i, i + AiConfig.red_dot_bg_window):
                rgb = image_data[j, x]
                if not rgb_valid(rgb, bg_rgb):
                    break
                count = count + 1
            if count == AiConfig.red_dot_bg_window:
                return True
    return False


def red_dot_horizontal_valid(image_data, x, y):
    for i in range(x - AiConfig.red_dot_bg_length + AiConfig.red_dot_bg_window, x):
        for bg_rgb in AiConfig.red_dot_bg_rgb:
            count = 0
            for j in range(i - AiConfig.red_dot_bg_window, i):
                rgb = image_data[y, j]
                if not rgb_valid(rgb, bg_rgb):
                    break
                count = count + 1
            if count == AiConfig.red_dot_bg_window:
                return True
    return False


def rgb_delta(image_array, y, x, color_index):
    red, green, blue = image_array[y, x, 0], image_array[y, x, 1], image_array[y, x, 2]

    rgb_threshold = AiConfig.rgb_threshold[color_index]
    if color_index == AiConfig.red_index or color_index == AiConfig.orange_index:
        red = 255 - red
    elif color_index == AiConfig.blue_index:
        blue = 255 - blue
    elif color_index == AiConfig.green_index:
        green = 255 - green

    if red < rgb_threshold['red'] and green < rgb_threshold['green'] and blue < rgb_threshold['blue']:
        return False
    return True


def rgb_valid(rgb, bg_rgb):
    thresholds = np.subtract(rgb, bg_rgb)
    for t in thresholds:
        if abs(t) > AiConfig.red_dot_bg_threshold:
            return False
    return True


if __name__ == '__main__':
    red_dot_array, red_index, red_count = generate_red_dot(15)
    contact_region = (559, 158, 307, 651)
    start_time = time.time()
    find_new_message(contact_region, red_dot_array, red_index, red_count)
    print("--- find_new_message %s seconds ---" % (time.time() - start_time))
