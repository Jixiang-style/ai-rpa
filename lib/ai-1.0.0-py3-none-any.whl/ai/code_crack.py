import math

import numpy as np
from PIL import Image, ImageFilter

from ai.config import AiConfig
from ai.image import Point


class WandFilter:
    def __init__(self, x_threshold, y_threshold, connect=4):
        self.x_threshold = x_threshold
        self.y_threshold = y_threshold
        self.wand_min_x = math.inf
        self.wand_max_x = 0
        self.wand_min_y = math.inf
        self.wand_max_y = 0
        self.connect = connect

    def filter(self, base_data, seed_x, seed_y):
        height, width = base_data.shape
        seed_mark = np.zeros((height, width))
        seed_list = [Point(seed_x, seed_y)]
        label = 255
        if self.connect == 4:
            connects = [Point(1, 0), Point(-1, 0), Point(0, 1), Point(0, -1)]
        else:
            connects = [Point(1, 0), Point(-1, 0), Point(0, 1), Point(0, -1),
                        Point(1, 1), Point(-1, 1), Point(-1, -1), Point(1, -1)]
        min_x = math.inf
        max_x = 0
        min_y = math.inf
        max_y = 0

        while len(seed_list) > 0:
            current_point = seed_list.pop(0)
            seed_mark[current_point.y, current_point.x] = label
            for i in range(len(connects)):
                if i < 2:
                    threshold = self.x_threshold
                else:
                    threshold = self.y_threshold
                tmp_x = current_point.x + connects[i].x
                tmp_y = current_point.y + connects[i].y
                if tmp_x < 0 or tmp_y < 0 or tmp_x >= width or tmp_y >= height:
                    continue
                if seed_mark[tmp_y, tmp_x] == 0:
                    gray_diff = abs(base_data[tmp_y][tmp_x] - base_data[current_point.y][current_point.x])
                    if gray_diff <= threshold:
                        seed_mark[tmp_y, tmp_x] = label
                        seed_list.append(Point(tmp_x, tmp_y))
                        if tmp_y < min_y:
                            min_y = tmp_y
                        if tmp_y > max_y:
                            max_y = tmp_y
                        if tmp_x < min_x:
                            min_x = tmp_x
                        if tmp_x > max_x:
                            max_x = tmp_x

        return seed_mark


def contour_enhance(base_image, contour_threshold, cross_filter_params):
    contour_image = base_image.filter(ImageFilter.CONTOUR)

    base_data = np.asarray(base_image, dtype=int)
    contour_data = np.asarray(contour_image, dtype=int)
    cross_filter = CrossFilter(cross_filter_params)
    cross_data = cross_filter.filter(contour_data)

    result = np.zeros(shape=base_data.shape)
    rows, cols = base_data.shape[0], base_data.shape[1]
    for i in range(0, rows):
        for j in range(0, cols):
            if cross_data[i, j] == 1:
                contour_data[i, j] = 0
                base_data[i, j] = 0
            if contour_data[i, j] <= contour_threshold:
                diff = (base_data[i, j] - contour_data[i, j])
                if diff >= 0:
                    result[i, j] = diff
            else:
                result[i, j] = base_data[i, j]
    return result


class CrossFilter:
    def __init__(self, params):
        self.cross_filter_threshold = params[0]
        self.cross_filter_min_size = params[1]
        self.cross_filter_size = params[2]
        self.cross_filter_extend_size = params[3]

    def filter(self, data):
        rows, cols = data.shape[0], data.shape[1]
        result = np.full(shape=data.shape, fill_value=255)
        for i in range(0, rows):
            for j in range(0, cols):
                h_right_result = self._horizontal_iterate_right(data, i, j)
                h_left_result = self._horizontal_iterate_left(data, i, j)
                v_down_result = self._vertical_iterate_down(data, i, j)
                v_up_result = self._vertical_iterate_up(data, i, j)
                if (h_right_result or h_left_result) and (v_down_result or v_up_result):
                    result[i, j] = 1
                    if h_right_result:
                        result[i, j:j + 1 + self.cross_filter_size] = 1
                    if h_left_result:
                        result[i, j - 1 - self.cross_filter_size:j] = 1
                    if v_down_result:
                        result[i:i + 1 + self.cross_filter_size, j] = 1
                    if v_up_result:
                        result[i - 1 - self.cross_filter_size:i, j] = 1
        return result

    def get_cross_xy(self, data):
        rows, cols = data.shape[0], data.shape[1]
        result = []
        for i in range(0, rows):
            for j in range(0, cols):
                h_right_result = self._horizontal_iterate_right(data, i, j)
                h_left_result = self._horizontal_iterate_left(data, i, j)
                v_down_result = self._vertical_iterate_down(data, i, j)
                v_up_result = self._vertical_iterate_up(data, i, j)
                if (h_right_result or h_left_result) and (v_down_result or v_up_result):
                    result.append((j, i))
        return result

    def _horizontal_iterate_right(self, contour_data, row, j):
        size = self.cross_filter_size
        extend_size = self.cross_filter_extend_size
        x1, x2 = j + 1, j + 1 + size
        a = contour_data[row, x1:x2]
        count = len(a[a < self.cross_filter_threshold])
        if count == size:
            return True
        elif self.cross_filter_min_size < count < size:
            x2 = j + 1 + extend_size
            a = contour_data[row, x1:x2]
            extend_count = len(a[a < self.cross_filter_threshold])
            if extend_count >= extend_size - size + count:
                return True
        return False

    def _horizontal_iterate_left(self, contour_data, row, j):
        size = self.cross_filter_size
        extend_size = self.cross_filter_extend_size
        x1, x2 = j - 1 - size, j - 1
        a = contour_data[row, x1:x2]
        count = len(a[a < self.cross_filter_threshold])
        if count == size:
            return True
        elif self.cross_filter_min_size < count < size:
            x1 = j - 1 - extend_size
            a = contour_data[row, x1:x2]
            extend_count = len(a[a < self.cross_filter_threshold])
            if extend_count >= extend_size - size + count:
                return True
        return False

    def _vertical_iterate_up(self, contour_data, i, col):
        size = self.cross_filter_size
        extend_size = self.cross_filter_extend_size
        y1, y2 = i - 1 - size, i - 1
        a = contour_data[y1:y2, col]
        count = len(a[a < self.cross_filter_threshold])
        if count == size:
            return True
        elif self.cross_filter_min_size < count < size:
            y1 = i - 1 - extend_size
            a = contour_data[y1:y2, col]
            extend_count = len(a[a < self.cross_filter_threshold])
            if extend_count >= extend_size - size + count:
                return True
        return False

    def _vertical_iterate_down(self, contour_data, i, col):
        size = self.cross_filter_size
        extend_size = self.cross_filter_extend_size
        y1, y2 = i + 1, i + 1 + size
        a = contour_data[y1:y2, col]
        count = len(a[a < self.cross_filter_threshold])
        if count == size:
            return True
        elif self.cross_filter_min_size < count < size:
            y2 = i + 1 + extend_size
            a = contour_data[y1:y2, col]
            extend_count = len(a[a < self.cross_filter_threshold])
            if extend_count >= extend_size - size + count:
                return True
        return False


def expand_wand_data(wand_data, expand_size):
    rows, cols = wand_data.shape[0], wand_data.shape[1]
    result = np.zeros(shape=wand_data.shape, dtype=int)
    for i in range(expand_size, rows - expand_size):
        for j in range(expand_size, cols - expand_size):
            if wand_data[i, j] == 255:
                result[i, j] = 255
                for k in range(1, expand_size + 1):
                    result[i - k, j], result[i + k, j] = 255, 255
                    result[i, j - k], result[i, j + k] = 255, 255
                    result[i - k, j - k], result[i - k, j + k] = 255, 255
                    result[i + k, j - k], result[i + k, j + k] = 255, 255
    return result


def _color_diff(color1, color2):
    if isinstance(color2, tuple):
        return sum([abs(color1[i] - color2[i]) for i in range(0, len(color2))])
    else:
        return abs(color1 - color2)


def get_wand_candidate(base_image, seed_color, seed_x, thresh):
    image_array = np.asarray(base_image, dtype=int)
    result = []
    for i, value in enumerate(image_array[:, seed_x]):
        if _color_diff(value, seed_color) < thresh:
            result.append((seed_x, i))
    return result


def get_shape_edge(gray_image, wand_data, edge_data):
    rows, cols = wand_data.shape[0], wand_data.shape[1]
    count = 0
    result = np.full(shape=wand_data.shape, fill_value=255)
    for i in range(0, rows):
        for j in range(0, cols):
            if wand_data[i, j] == 255 and edge_data[i, j] > 55:
                result[i, j] = 0
                count = count + 1

    cross_filter_params = AiConfig.cross_filter_params
    cross_filter = CrossFilter(cross_filter_params)
    cross_xy = cross_filter.get_cross_xy(result)

    x_dict, y_dict = {}, {}
    for p in cross_xy:
        if p[0] in x_dict:
            x_dict[p[0]] = x_dict[p[0]] + 1
        else:
            x_dict[p[0]] = 1
        if p[1] in y_dict:
            y_dict[p[1]] = y_dict[p[1]] + 1
        else:
            y_dict[p[1]] = 1
    x_list, y_list = [], []

    for x in x_dict:
        if x_dict[x] >= 2:
            x_list.append(x)
    for y in y_dict:
        if y_dict[y] >= 2:
            y_list.append(y)
    if len(x_list) == 0 or len(y_list) == 0:
        min_x, min_y, max_x, max_y = math.inf, math.inf, 0, 0
    else:
        min_x, min_y, max_x, max_y = min(x_list), min(y_list), max(x_list), max(y_list)
    return result, count, min_x, min_y, max_x, max_y


class ShapeEdge(object):
    def __init__(self, x, y):
        self.x = x
        self.y = y


def rect_filter(shape_edge, min_x, min_y, max_x, max_y):
    rows, cols = shape_edge.shape
    count = 0
    for i in range(0, rows):
        for j in range(0, cols):
            if shape_edge[i, j] != 0:
                continue
            if i == min_y or i == max_y or j == min_x or j == max_x:
                count = count + 1
    total_count = 2 * ((max_x - min_x) + (max_y - min_y))
    if total_count == 0:
        return False
    ratio = count / total_count
    if ratio > 0.50 and 100 < total_count < 240:
        return True
    return False


def _check_edge(edge_his, x):
    for i in range(x - 15, x + 1):

        if edge_his[i] > 10:
            return True
    return False


def calc_mask(image_array, edge_data, fill_edge, cube_xy):
    x1, y1, x2, y2 = cube_xy
    width = x2 - x1
    start = x2
    end = image_array.shape[1] - width

    slide_cube = image_array[y1:y2, x1:x2]
    slide_edge = fill_edge[y1:y2, x1:x2]
    sub_edge = edge_data[y1:y2, :]
    edge_his = np.count_nonzero(sub_edge > 170, axis=0)

    min_variance = float("inf")
    x = 0
    for x1 in range(start, end):
        if not _check_edge(edge_his, x1):
            continue
        x2 = x1 + width
        data = image_array[y1:y2, x1:x2]
        diff_array = np.full(shape=data.shape, fill_value=255)

        count = 0
        total = 0
        for i in range(0, data.shape[0]):
            for j in range(0, data.shape[1]):
                if slide_edge[i, j] != 0:
                    continue
                for k in range(0, data.shape[2]):
                    count = count + 1
                    diff_array[i, j, k] = slide_cube[i, j, k] - data[i, j, k]
                    total = total + diff_array[i, j, k]
        diff_mean = total / count
        if diff_mean < 40:
            continue
        variance_sum = 0
        for i in range(0, diff_array.shape[0]):
            for j in range(0, diff_array.shape[1]):
                if slide_edge[i, j] != 0:
                    continue
                for k in range(0, diff_array.shape[2]):
                    variance_sum = variance_sum + pow(diff_array[i, j, k] - diff_mean, 2)

        variance = variance_sum / count
        if variance < min_variance:
            min_variance = variance
            x = x1
    x_candidate = []
    start, end = x - 10, x + width + 10
    if end > edge_his.shape[0]:
        end = edge_his.shape[0]
    for i in range(start, end):
        if edge_his[i] > 8:
            x_candidate.append(i)
    if len(x_candidate) == 0:
        return -1
    min_width_diff = math.inf
    x1, x2 = x, x + width
    for i in range(0, len(x_candidate)):
        for j in range(i + 1, len(x_candidate)):
            w = x_candidate[j] - x_candidate[i]
            width_diff = w - width
            if 0 < width_diff < min_width_diff:
                x1, x2 = x_candidate[i], x_candidate[j]
                min_width_diff = width_diff
    result = (x1 + x2) / 2
    return result


def fill_shape_edge(shape_edge, min_x, min_y, max_x, max_y):
    x1, y1, x2, y2 = min_x, min_y, max_x, max_y
    row_range = {}
    for i in range(y1, y2 + 1):
        start, end = math.inf, 0
        for j in range(x1 - 10, x2 + 11):
            if shape_edge[i, j] == 0:
                if j <= start:
                    start = j
                if j >= end:
                    end = j
        if start < x1:
            start = x1
        if end > x2:
            end = x2
        row_range[i] = (start, end)

    col_range = {}
    for j in range(x1, x2 + 1):
        start, end = math.inf, 0
        for i in range(y1 - 10, y2 + 11):
            if shape_edge[i, j] == 0:
                if i < start:
                    start = i
                if i > end:
                    end = i
        if start < y1:
            start = y1
        if end > y2:
            end = y2
        col_range[j] = (start, end)

    a = np.full(shape=shape_edge.shape, fill_value=255)
    for i in range(y1, y2 + 1):
        start, end = row_range[i]
        for j in range(start, end + 1):
            a[i, j] = 0

    b = np.full(shape=shape_edge.shape, fill_value=255)
    for j in range(x1, x2 + 1):
        start, end = col_range[j]
        for i in range(start, end + 1):
            b[i, j] = 0

    result = np.full(shape=shape_edge.shape, fill_value=255)
    for i in range(y1, y2 + 1):
        for j in range(x1, x2 + 1):
            if a[i, j] == 0 and b[i, j] == 0:
                result[i, j] = 0
    return result


def cut_shape_edge(shape_edge, cube_xy):
    x1, y1, x2, y2 = cube_xy
    result = np.full(shape=shape_edge.shape, fill_value=255)
    for i in range(y1, y2 + 1):
        for j in range(x1, x2 + 1):
            result[i, j] = shape_edge[i, j]
    return result


def get_slide_distance(base_image):
    seed_color = AiConfig.seed_search_color
    seed_x = AiConfig.seed_search_start_x
    thresh = AiConfig.seed_search_thresh

    gray_image = base_image.convert('L')
    contour_enhance_data = contour_enhance(gray_image, 200, AiConfig.cross_filter_params)
    edge_image = gray_image.filter(ImageFilter.FIND_EDGES)
    edge_data = np.asarray(edge_image)

    wand_seed_list = get_wand_candidate(base_image.convert(AiConfig.wand_candidate_type), seed_color, seed_x, thresh)
    visited_array = np.zeros(contour_enhance_data.shape)
    cube_xy = None
    fill_edge = None
    for seed in wand_seed_list:
        seed_x, seed_y = seed
        if visited_array[seed_y, seed_x] == 255:
            continue
        height, width = contour_enhance_data.shape
        wand = WandFilter(AiConfig.wand_x_threshold, AiConfig.wand_y_threshold, AiConfig.wand_connect_num)
        wand_data = wand.filter(contour_enhance_data, seed_x, seed_y)
        wand_data = np.asarray(wand_data, dtype=int).reshape((height, width))
        visited_array = np.add(visited_array, wand_data)
        wand_data = expand_wand_data(wand_data, 2)
        shape_edge, point_count, min_x, min_y, max_x, max_y = get_shape_edge(gray_image, wand_data, edge_data)
        result = rect_filter(shape_edge, min_x, min_y, max_x, max_y)
        if result:
            cube_xy = (min_x + 3, min_y + 3, max_x - 3, max_y - 3)
            fill_edge = fill_shape_edge(shape_edge, min_x, min_y, max_x, max_y)
            fill_edge = cut_shape_edge(fill_edge, cube_xy)
            break
    if fill_edge is None:
        return -1
    target_x = calc_mask(np.asarray(base_image.convert('RGB'), dtype=int), edge_data, fill_edge, cube_xy)
    slide_distance = target_x - (min_x + max_x) / 2
    return slide_distance
